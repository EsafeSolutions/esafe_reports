// Copyright (c) 2026 Lumen Solutions. All rights reserved.
// SPDX-License-Identifier: LicenseRef-Lumen-Proprietary
// Proprietary and confidential. See license.txt. "Lumen Reports" is a trademark of Lumen Solutions.
import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/mobile',
    name: 'MobilePOS',
    component: () => import('@/pages/MobilePOS.vue'),
    meta: { mobile: true, autoReload: true },
  },
  {
    path: '/pos',
    name: 'POSConnection',
    component: () => import('@/pages/POSConnection.vue'),
  },
  {
    path: '/',
    name: 'DashboardList',
    component: () => import('@/pages/DashboardList.vue'),
    meta: { autoReload: true },
  },
  {
    path: '/new',
    name: 'DashboardNew',
    component: () => import('@/pages/DashboardNew.vue'),
  },
  {
    path: '/new/blank',
    name: 'DashboardBlank',
    component: () => import('@/pages/DashboardBuilder.vue'),
  },
  {
    path: '/ask',
    name: 'AskAI',
    component: () => import('@/pages/AskAI.vue'),
  },
  {
    path: '/brand',
    name: 'BrandSettings',
    component: () => import('@/pages/BrandSettings.vue'),
  },
  {
    path: '/dashboard/:slug',
    name: 'DashboardView',
    component: () => import('@/pages/DashboardView.vue'),
    props: true,
    meta: { autoReload: true },
  },
  {
    path: '/dashboard/:slug/edit',
    name: 'DashboardEdit',
    component: () => import('@/pages/DashboardBuilder.vue'),
    props: true,
  },
  {
    path: '/dashboard/:slug/report',
    name: 'DashboardReport',
    component: () => import('@/pages/DashboardReport.vue'),
    props: true,
  },
  {
    // for another app's page, such as ESAFE POS Insights: the dashboard without
    // the app's header, navigation or edit controls
    path: '/embed/:slug',
    name: 'DashboardEmbed',
    component: () => import('@/pages/DashboardView.vue'),
    props: (route) => ({ slug: route.params.slug, embed: true }),
    meta: { embed: true, autoReload: true },
  },
]

export default createRouter({
  // Both entry points serve the same app; existing bookmarks and POS embeds keep working.
  history: createWebHistory(window.location.pathname.startsWith('/esafe-report') ? '/esafe-report' : '/lumen'),
  routes,
})
