<div align="center">

<img src="lumen_reports/public/logo/blabs-report.svg" width="76" height="76" alt="Esafe BLABS" />

# Esafe BLABS

**Live sales dashboards and reports connected to ESAFE POS.**

Build dashboards by dragging, from a template, or by asking in plain words.
Style them your way, send them as PDF reports, and use the whole app in English or Arabic.

</div>

Open `/esafe-report/pos` to check the same-site POS connection and create the sales
dashboard. Then use **POS → Insights → Sales dashboard**. See
[ESAFE POS setup](docs/ESAFE-POS-SETUP.md) for installation and permissions.

For the installable Android/iPhone experience, open `/esafe-report/mobile`.
It includes date/outlet filters, reports, sale/return push alerts and daily summaries.
See [Mobile app setup](docs/MOBILE-APP.md) for deployment and device installation.

The mobile app also includes searchable product prices, barcode lookup, current
warehouse inventory, and category/product sales with CSV exports. An Android APK
and native source are available in `downloads/`. iPhone uses the installable
Home Screen app. See [download and deployment guide](native/README.md).

This customization keeps the technical app name `lumen_reports`, existing DocTypes,
roles, API methods and `/lumen` URLs compatible with ESAFE POS and existing sites.
The original licence, source notices and entitlement checks
remain in place. Role names and API identifiers below are the existing technical names.

---

## Why Esafe BLABS

Frappe ships capable but plain reporting. Getting a straight answer usually means
exporting to a spreadsheet or waiting on a custom script report.

Esafe BLABS is a standalone Vue 3 single-page app served at `/esafe-report` (also available at `/lumen`). It is **not** a BI
suite for analysts. It is an operational dashboard layer for the people who run the
business, built on the doctypes you already have.

- **A designed look, not default charts.** A cohesive design system, per-dashboard
  themes, and charts that recolor with the theme.
- **Live updates.** When an underlying document changes, affected widgets refresh in
  place over websockets. No refresh button.
- **No-code studio.** Start from a template or a blank canvas, edit any widget in a
  side inspector with a live preview, and drag and resize on a 12-column grid.
- **Permission-safe by construction.** Esafe BLABS never runs raw SQL. Every widget stores
  a query definition that the server compiles through Frappe's permission layer,
  checking read access on the base doctype *and* every joined doctype. PDF reports
  and scheduled emails are rendered with the same checks, as the person reading them.

## Features

**19 chart types and 4 layout elements**

| | |
|---|---|
| Trends | Line, Area, Sparkline, Waterfall |
| Comparisons | Bar (single or grouped), Stacked bar, Ranked bars, Radar |
| Composition | Donut, Pie, Funnel, Radial rings |
| Progress | Number card, Gauge, Progress bars |
| Distribution | Heatmap, Scatter / bubble |
| Detail | Table, Tree report |
| Layout elements | Heading, Text, Divider, Image |

**Building**

- **Starter templates.** Executive Overview, Products and Retail, Receivables,
  Purchasing and Team Workload. Each one is validated against the site's own data
  when it is created, and widgets the site cannot answer are left out. Only templates
  whose doctypes the user can read are offered. Team Workload works on any Frappe
  site, the other four use ERPNext doctypes.
- **Studio.** A side inspector with live preview, undo and redo (Ctrl+Z,
  Ctrl+Shift+Z), duplicate (Ctrl+D), and autosave for drafts. Published dashboards
  change only on an explicit Save changes.
- **Themes, per dashboard.** Six presets (ESAFE Light, ESAFE Dark, Emerald, Midnight,
  Sand, Paper), plus primary and secondary color, card style (flat, outlined,
  elevated, glass), corner radius, density, background (solid, gradient, brand tint)
  and font. Charts read their colors from the dashboard's theme. A color set by hand
  on a widget is kept.
- **Visual identity**, site-wide, at `/lumen/brand`. One saved look every dashboard
  and every report follows unless it sets its own: organization name, logo,
  letterhead, an own line in the middle of the page foot (beside the "Created by
  Esafe BLABS" credit, which always prints), the two faces a report prints in,
  and a default theme. A
  dashboard overrides it field by field, so changing the identity restyles
  everything that never overrode that field. Upload the identity as an image and
  Esafe BLABS reads the colors out of it, with the palette measured from the pixels and,
  when a Gemini key is set, the primary and secondary picked by the AI. Nothing is
  applied until the person confirms it. Needs Lumen Manager or System Manager.
- **Two report fonts, one Latin and one Arabic.** A Latin family carries no Arabic
  letters, so a report that named only one would leave every Arabic line to whatever
  face the server happens to have, which on a Linux bench is DejaVu. Each report
  therefore names a Latin family and an Arabic family, and the browser picks per
  character. Both are chosen at `/lumen/brand` and both ship with the app, so a bench
  with no outbound network prints exactly the same page. Latin: Plus Jakarta Sans or
  Inter. Arabic: IBM Plex Sans Arabic, Cairo, Tajawal, Almarai or Noto Naskh Arabic.
- **Form follows data.** The chart type that suits the numbers is chosen by default,
  and the variant bar offers only the alternatives that also make sense.

**AI** *(optional, bring-your-own Gemini key)*

- **Copilot.** A panel in the studio that changes the whole dashboard, or one
  selected widget, on request: arrange the layout, apply a theme, retitle, switch
  chart types within the same shape family, recolor, remove, add headings and notes,
  build new widgets from the site's data, change what a widget measures, write an
  executive summary, or explain what stands out. Every proposal is shown as a list of
  changes first, and applying it is a single undo step. It replies in the user's
  language.
- **Ask AI** at `/lumen/ask`. Describe a report in plain English and Esafe BLABS generates
  validated widgets with a short written analysis, to save as a new dashboard or add
  to an existing one. It asks a clarifying question when a request is genuinely
  ambiguous, and surfaces the assumptions it made as one-tap refinements.

**Reading and sharing**

- **Dashboard filters.** Select, Link (searchable), Checkbox, **date range**
  (presets such as today or this month, or two dates) and **line-item** filters, all
  combined with AND. A date range can start from a default preset.
- **Cross-filtering.** Click any chart segment to refocus every other widget, across
  document and line-item grain. Dimensions stack, each with a removable chip.
- **Related fields (one-hop joins).** Report on attributes pulled *live* from linked
  masters (Sales Invoice line to Item to **Brand / Item Group**) at line grain,
  without double-counting.
- **Two-dimensional grouping.** A second breakdown turns a chart into grouped bars,
  stacked bars, multi-line, a heatmap or a radar.
- **Tree reports.** Drill from category to brand to item, totals rolled up, every row
  showing its share of the whole.
- **Computed metrics.** Values that exist in no field: average check-in time, hours
  worked, payment terms in days, outstanding as a percentage of invoiced.
- **PDF reports** at `/lumen/dashboard/<slug>/report`. A4 or Letter, a header carrying
  the visual identity (organization name, logo and optional letterhead, falling back
  to the default Company where no identity is set), page numbers, the dashboard's
  current filters, an optional AI executive summary, and an English or Arabic
  edition. Rendered on the server with WeasyPrint, which ships with Frappe. Fonts are
  bundled, and the renderer fetches nothing from outside the site.
- **Scheduled delivery.** Email a dashboard's PDF daily, weekly or monthly to users
  of the site. Each copy is rendered as its recipient, so it carries their
  permissions, and a recipient who cannot open the dashboard receives nothing. A test
  copy can be sent to yourself first.
- **Arabic interface.** A language switch in the app turns the whole interface, the
  PDFs and the emails to Arabic, right to left.
- **Result caching** with automatic doc-event invalidation, **CSV / SVG export**, and
  **publish-based visibility** (users see published dashboards plus their own drafts).
- **Responsive.** Built for phones as well as desktops.

## Requirements

- Frappe Framework **v14**, **v15** or **v16**
- Works alongside ERPNext, or on any custom app. Esafe BLABS reads whatever doctypes exist.
- The AI features are optional and need your own Google Gemini API key
- **PDF reports and scheduled delivery need v15 or v16.** They render with
  WeasyPrint, which ships with those versions but not v14, so on v14 the Report
  button and the schedule panel hide themselves and the whole dashboard experience
  works as normal. (If a v14 site installs WeasyPrint itself, they appear.)
- Scheduled delivery also needs an outgoing **Email Account** on the site and the
  Frappe scheduler running. Due schedules are picked up every 10 minutes.

## Installation

From your bench directory:

```bash
bench get-app https://github.com/EsafeSolutions/esafe_reports.git
bench --site your-site.localhost install-app lumen_reports
bench build --app lumen_reports
```

Then open `https://your-site.localhost/esafe-report/pos`.

> The SPA is built from `frontend/` by the root `yarn build` script, which
> `bench build` runs for you. To build it by hand: `yarn build` in the app root.

### Frontend development

```bash
cd apps/lumen_reports/frontend
yarn install
yarn dev      # Vite dev server with HMR, proxied to your bench
yarn build    # production build, served at /lumen
```

## Permissions

Esafe BLABS ships four roles (created on install):

| Role | Can do |
|---|---|
| **Lumen Viewer** | Open the app and see published dashboards |
| **Lumen Restricted Viewer** | See **only** dashboards that name them, which is how you give someone exactly one dashboard |
| **Lumen Builder** | Viewer, plus create dashboards, edit or delete their own, and schedule reports |
| **Lumen Manager** | Full control over all dashboards and schedules |

Three independent layers:

1. **App access.** `/lumen` requires one of the roles above (System Managers always
   have access).
2. **Dashboard visibility.** Drafts are private to their owner. Published dashboards
   are visible to everyone with Esafe BLABS access, unless the dashboard names an audience
   ("Who can see it" in settings): roles, specific people, or both. Restricted
   Viewers invert the default: they see nothing except dashboards that name them.
3. **Data.** Every widget query runs through Frappe's permission layer for the
   *viewing* user. A builder can only report on doctypes their roles let them read,
   and two users can open the same dashboard and correctly see different numbers.
   PDFs and scheduled emails follow the same rule for the person receiving them.

Assign the roles from the desk (User, then Roles) like any other Frappe role.

## AI setup (optional)

The AI features run on **Google Gemini**, using a key you provide. Usage, and any
charge for it, sits with the Google account that owns the key.

1. Open `/lumen/ask` in the app.
2. Get a key at [aistudio.google.com/apikey](https://aistudio.google.com/apikey). A
   step-by-step guide is on the page.
3. Paste it as your **personal key**, or, as a System Manager, set a **site-wide
   key** shared by everyone (a personal key always takes priority).

Keys are stored **encrypted** in the site database, never returned to the browser and
never included in error messages. The model only ever emits Esafe BLABS's query
specification, or the copilot's list of operations, and both are executed through the
same permission-aware engine as every other widget. The AI never touches the
database directly.

**What Google receives:** the user's request, the structure of the relevant doctypes
(names, fields, labels, types), summary figures (record counts, date ranges, a few
field values with counts) and, for analyses and executive summaries, the totals shown
on the charts with their category names. It never receives whole documents or table
rows.

## Architecture

| Layer | What it does |
|---|---|
| `Lumen Dashboard` / `Lumen Widget` doctypes | Dashboards, theme, widget query specs (JSON), layout, filters |
| `Lumen Report Schedule` / `Lumen Report Recipient` doctypes | Scheduled PDF delivery and its recipients |
| `query_engine.py` | Compiles a JSON query to `frappe.get_list`, so permissions always apply |
| `report_engine.py` | `frappe.qb` engine for line-item grain, one-hop joins, matrices, trees, computed metrics |
| `realtime.py` | Doctype to dashboard registry, publishes invalidation on doc change |
| `api.py` | Dashboard, widget and builder endpoints |
| `starters.py` | Starter templates, validated against the site's data on creation |
| `ai.py` | Ask AI orchestration (Gemini), validated through the query engines |
| `copilot.py` | Studio copilot: typed operations, simulated on a copy before they are proposed |
| `report.py` | PDF rendering (WeasyPrint), English and Arabic |
| `schedules.py` | Schedule runner (scheduler cron, every 10 minutes) and delivery as each recipient |
| `licensing.py` | Frappe Cloud subscription check, cached, and never blocking reads |
| `integrations/esafepos.py` / `integrations/lumenpos.py` | ESAFE POS and legacy Insights entry points: shared read-only status, one-time dashboard setup, embed URL |
| `frontend/` | Vue 3 + Vite + frappe-ui + ECharts SPA served at `/lumen` |
| `lumen_reports/dev/` | Developer verification helpers, not part of the product surface |

## ESAFE POS Insights (integration)

ESAFE POS can show a POS sales dashboard from Esafe BLABS inside the POS. The two
apps meet only at runtime, through the calls below, and neither imports the other.

| Call | What it does |
|---|---|
| `lumen_reports.integrations.esafepos.get_status` (GET) | Read-only state for the POS page: `contract`, `license`, `dashboard_exists`, `can_view`, `can_create`, `reason` (`needs_erpnext`, `not_set_up`, `needs_role`, `not_in_audience`, or empty when ready), `slug`, `url`, `embed_url` |
| `lumen_reports.integrations.esafepos.ensure_dashboard` (POST, optional `lang`) | Creates the `lumenpos-sales` dashboard once and never overwrites it. Returns `status: ready`, or a refusal with a `message`: `needs_erpnext`, `license_expired`, `not_permitted`, `not_available` |

The legacy `lumen_reports.integrations.lumenpos` methods continue to serve the same
contract. Both `esafepos` and `lumenpos` are recognized as installed POS apps.

- **Embed** at `/lumen/embed/<slug>`, optionally with `?lang=en|ar` and
  `?theme=light|dark`. It shows the dashboard with its filters and live updates,
  without the app header, navigation or edit controls.
- **Access** requires an Esafe BLABS role. **Lumen Restricted Viewer** plus
  `EsafePOS Manager` lets a POS manager see this dashboard and nothing else. Legacy
  installations use `LumenPOS Manager`; new dashboards include whichever manager
  roles exist on the site. The numbers still need read permission on POS Invoice.
- **Setup** needs Lumen Builder, Lumen Manager or System Manager, so call
  `ensure_dashboard` from an administrator's action.
- **Data** comes from submitted POS Invoices only, so sales consolidated into Sales
  Invoices when a register closes are not counted twice.
- Contract version 3. Checks: `bench --site <site> execute lumen_reports.dev.test_lumenpos.run`.

## Reports another app computes

Some numbers cannot be written as a dashboard widget. The cost of goods sold reads a
stock ledger, expands a bundle into its parts and estimates what has not been posted
yet; a cash count compares a drawer against a shift. That knowledge belongs to the app
that owns the subject, and Esafe BLABS runs no raw SQL by design. So the owning app
keeps the arithmetic and registers it here, and Esafe BLABS becomes the way it is
reached: it holds the entry point, the licence state, the role gate and the filter
contract, and the owning app's own permission rule is asked before its code runs.

In the other app's `hooks.py`:

```python
lumen_report_sources = ["lumenpos.reporting.sources"]
```

That path is a callable returning one definition or a list of them:

```python
def sources():
    return [
        {
            "key": "lumenpos.sales_summary",          # <app>.<report>
            "label": "Sales summary",
            "method": "lumenpos.api.reports.sales_summary",
            "filters": ["from_date", "to_date", "pos_profile", "outlet"],
            "capability": "lumenpos.api.reports.can_see_sales_reports",   # optional
            "roles": ["LumenPOS Manager", "LumenPOS Reports"],            # optional
        }
    ]
```

| Call | What it does |
|---|---|
| `lumen_reports.integrations.sources.list_reports` (GET) | What is registered on this site: `key`, `label`, `app`, `filters`, `roles`, `can_run`, plus `contract`, `license` and `has_role` |
| `lumen_reports.integrations.sources.run_report` (GET or POST, `key` and optional `filters`) | Runs one report and returns the owning app's result untouched under `result`, or a refusal with a `message`: `needs_role`, `unknown_report`, `not_permitted`, `not_available` |

- **`method` and `capability` are dotted paths into the registering app**, and must
  start with the app its `key` names, so a hook cannot reach into a third app. No path
  ever comes from the caller.
- **Only the filters a definition declares are forwarded**, so a caller cannot smuggle
  an argument past the owning app. A definition that is malformed, names an app that is
  not installed, or writes `filters` as anything but a list is dropped rather than run
  with the wrong arguments.
- **The owning app decides who may see it.** Its `capability` is called before its
  `method`, and a rule that raises counts as a refusal.
- **A viewer needs an Esafe BLABS role, unless the definition names roles of its own.**
  `roles` lists roles that stand in for an Esafe BLABS role **for that report only**: a shop
  manager who runs the till should not have to be given a reporting role as well to
  read the till's own numbers. Those roles open nothing else, not a dashboard, not the
  studio, not another app's report, and the owning app's `capability` still decides.
  Without `roles`, an Esafe BLABS role is required, which is what lets a host app show an
  "install Esafe BLABS" card instead of a report.
- **The licence is reported, never enforced.** `list_reports` returns the licence
  state so a host app can show a banner, and a report still runs: reads are not
  blocked here, the same way they are not blocked anywhere else in this app.
- **Errors travel as they are.** A refusal the owning app wrote reaches the caller
  unchanged, because it is clearer than anything this app could invent.
- Not yet: PDF export and scheduled delivery of a registered report. The renderer draws
  dashboard widgets, and a registered result needs its own block type.
- Checks: `bench --site <site> execute lumen_reports.dev.test_sources.run`.

## Optional: demo data

Helpers to spin up a retail demo (ERPNext required): brands, item groups, about 185
sales invoices, and a ready-made dashboard:

```bash
bench --site your-site.localhost execute lumen_reports.retail_setup.run
bench --site your-site.localhost execute lumen_reports.retail_setup.enrich
bench --site your-site.localhost execute lumen_reports.retail_setup.enrich_items
bench --site your-site.localhost execute lumen_reports.retail_dashboard.run
```

## Licence

**Proprietary. © 2026 Lumen Solutions. All rights reserved.**

This repository is public so that Frappe Cloud can build and distribute the app, and
so you can read exactly what runs on your site. **It is not open source.** Being able
to read the source does not grant a right to copy, redistribute or resell it.

Using the app requires a valid subscription or purchase. You may modify it for use on
your own licensed sites. You may not distribute it, in original or modified form. See
[`license.txt`](license.txt) for the full terms.

"Lumen Reports" and the Lumen Reports logo are trademarks of Lumen Solutions and are not
covered by any code licence. See [`TRADEMARKS.md`](TRADEMARKS.md).

Third-party open-source components retain their own licences. The bundled fonts (Plus
Jakarta Sans, Inter, IBM Plex Sans Arabic, IBM Plex Mono, Cairo, Tajawal, Almarai and
Noto Naskh Arabic) are under the SIL Open Font License, a copy of which is included
next to each of them in `lumen_reports/public/fonts/`.

Commercial enquiries: [hello@lumen-solutions.co](mailto:hello@lumen-solutions.co)
